// ============================================================================
// 5x52 Field Element -- Inline Hot-Path Implementations
// ============================================================================
//
// All performance-critical 5x52 operations are FORCE-INLINED to eliminate
// function-call overhead in ECC point operations (the #1 bottleneck).
//
// On x86-64 with -march=native, Clang/GCC generate MULX (BMI2) assembly
// from the __int128 C code -- identical to hand-written assembly but with
// superior register allocation (no callee-save push/pop overhead).
//
// This matches the strategy of bitcoin-core/secp256k1, which uses
// SECP256K1_INLINE static in field_5x52_int128_impl.h.
//
// Impact: eliminates ~2-3ns per field-mul call -> cumulative ~30-50ns
// savings per point double/add (which has 7+ field mul/sqr calls).
//
// Adaptation from bitcoin-core/secp256k1 field_5x52_int128_impl.h
// (MIT license, Copyright (c) 2013-2024 Pieter Wuille and contributors)
// ============================================================================

#ifndef SECP256K1_FIELD_52_IMPL_HPP
#define SECP256K1_FIELD_52_IMPL_HPP
#pragma once

#include <cstdint>
#include "secp256k1/u128_compat.hpp"

// Guard: 5x52 kernels need a 128-bit accumulator.
// On 64-bit GCC/Clang with native __int128 (SECP256K1_NO_INT128 undefined),
// u128_compat aliases unsigned __int128 — zero overhead.
// On wasm32 / 32-bit targets / SECP256K1_NO_INT128 set, u128_compat is a
// portable 32-bit-safe struct with explicit 64x64->128 multiplication.
// Either way, the kernels compile.
#if defined(__SIZEOF_INT128__) || defined(SECP256K1_NO_INT128)

// Suppress GCC -Wpedantic for __int128 (universally supported on 64-bit GCC/Clang)
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
#endif

// -- RISC-V 64-bit optimized FE52 kernels ---------------------------------
// On SiFive U74 (in-order dual-issue), hand-scheduled MUL/MULHU assembly
// for 5x52 Comba multiply with integrated secp256k1 reduction outperforms
// __int128 C++ code because:
//   1) Explicit register allocation avoids spills (25+ MUL ops)
//   2) Carry chain scheduling hides MUL latency on in-order pipeline
//   3) Branchless reduction integrated without separate passes
//
// Enabled by default when SECP256K1_HAS_RISCV_FE52_ASM is set by CMake.
// To disable and fall back to __int128 C++: -DSECP256K1_RISCV_FE52_DISABLE=1
#if defined(__riscv) && (__riscv_xlen == 64) && defined(SECP256K1_HAS_RISCV_FE52_ASM) \
    && !defined(SECP256K1_RISCV_FE52_DISABLE)
  #define SECP256K1_RISCV_FE52_V1 1
extern "C" {
    void fe52_mul_inner_riscv64(std::uint64_t* r, const std::uint64_t* a, const std::uint64_t* b);
    void fe52_sqr_inner_riscv64(std::uint64_t* r, const std::uint64_t* a);
}
#endif

// -- 4x64 assembly bridge for boundary-level FE52 optimizations ---------------
// Provides access to 4x64 ADCX/ADOX field_mul/sqr assembly from FE52 code.
// Used for pure sqr/mul chains (inverse, sqrt) where conversion at boundaries
// is negligible (~6ns) compared to per-op savings (~2ns x 269 ops = ~538ns).
// NOT used per-mul/sqr (GPU-style hybrid: same pointer, no conversion).
// Requires: SECP256K1_HAS_ASM + x86-64 (4x64 assembly always linked)
#if defined(SECP256K1_HAS_ASM) && (defined(__x86_64__) || defined(_M_X64))
  #define SECP256K1_HYBRID_4X64_ACTIVE 1
  // MinGW (GCC/Clang on _WIN32) uses Microsoft x64 ABI by default but our
  // GAS asm uses System-V x64 ABI — annotate with sysv_abi so the compiler
  // emits the right call adapter. MSVC has neither the syntax nor that
  // problem (it uses its own field_asm_x64.asm in MASM with Win64 ABI).
  #if defined(_WIN32) && (defined(__GNUC__) || defined(__clang__))
    extern "C" __attribute__((sysv_abi)) void field_mul_full_asm(
        const std::uint64_t* a, const std::uint64_t* b, std::uint64_t* result);
    extern "C" __attribute__((sysv_abi)) void field_sqr_full_asm(
        const std::uint64_t* a, std::uint64_t* result);
  #else
    extern "C" {
        void field_mul_full_asm(
            const std::uint64_t* a, const std::uint64_t* b, std::uint64_t* result);
        void field_sqr_full_asm(
            const std::uint64_t* a, std::uint64_t* result);
    }
  #endif
#endif // SECP256K1_HAS_ASM && x86-64

// Force-inline attribute -- ensures zero call overhead for field ops.
// The compiler generates MULX assembly automatically with -mbmi2.
#if defined(__GNUC__) || defined(__clang__)
  #define SECP256K1_FE52_FORCE_INLINE __attribute__((always_inline)) inline
#elif defined(_MSC_VER)
  #define SECP256K1_FE52_FORCE_INLINE __forceinline
#else
  #define SECP256K1_FE52_FORCE_INLINE inline
#endif

// Pointer-restrict portability shim: GCC/Clang use the double-underscore
// form, MSVC uses the single-underscore form. Without this, MSVC build
// fails at every fe52_mul_inner / fe52_sqr_inner declaration with
// "syntax error: missing ')'".
#if defined(_MSC_VER) && !defined(__clang__) && !defined(__GNUC__)
  #define SECP256K1_RESTRICT __restrict
#else
  // double-underscore form for GCC/Clang
  #define SECP256K1_RESTRICT __restrict__
#endif

// -- Hybrid 4x64 helper functions (placed after SECP256K1_FE52_FORCE_INLINE) --
#if defined(SECP256K1_HYBRID_4X64_ACTIVE)

  // Fused normalize_weak + 5x52->4x64 pack (single function, minimal overhead)
  SECP256K1_FE52_FORCE_INLINE
  void fe52_normalize_and_pack_4x64(const std::uint64_t* n, std::uint64_t* out) noexcept {
      constexpr std::uint64_t M = 0xFFFFFFFFFFFFFULL;   // 52-bit mask
      constexpr std::uint64_t M48v = 0xFFFFFFFFFFFFULL;  // 48-bit mask
      std::uint64_t t0 = n[0], t1 = n[1], t2 = n[2], t3 = n[3], t4 = n[4];
      // Pass 1: carry propagation
      t1 += (t0 >> 52); t0 &= M;
      t2 += (t1 >> 52); t1 &= M;
      t3 += (t2 >> 52); t2 &= M;
      t4 += (t3 >> 52); t3 &= M;
      // Overflow fold: x * 2^256 == x * 0x1000003D1 (mod p)
      std::uint64_t const x = t4 >> 48;
      t4 &= M48v;
      t0 += x * 0x1000003D1ULL;
      // Pass 2: re-propagate carry from fold
      t1 += (t0 >> 52); t0 &= M;
      t2 += (t1 >> 52); t1 &= M;
      t3 += (t2 >> 52); t2 &= M;
      t4 += (t3 >> 52); t3 &= M;
      // Pack to 4x64
      out[0] = t0 | (t1 << 52);
      out[1] = (t1 >> 12) | (t2 << 40);
      out[2] = (t2 >> 24) | (t3 << 28);
      out[3] = (t3 >> 36) | (t4 << 16);
  }

  // 4x64 -> 5x52 unpack (no normalization needed, output is magnitude 1)
  SECP256K1_FE52_FORCE_INLINE
  void fe64_unpack_to_fe52(const std::uint64_t* L, std::uint64_t* r) noexcept {
      constexpr std::uint64_t M = 0xFFFFFFFFFFFFFULL;
      r[0] =  L[0]                                      & M;
      r[1] = (L[0] >> 52) | ((L[1] & 0xFFFFFFFFFFULL)  << 12);
      r[2] = (L[1] >> 40) | ((L[2] & 0xFFFFFFFULL)     << 24);
      r[3] = (L[2] >> 28) | ((L[3] & 0xFFFFULL)        << 36);
      r[4] =  L[3] >> 16;
  }

#endif // SECP256K1_HYBRID_4X64_ACTIVE

namespace secp256k1::fast {

using namespace fe52_constants;

// ===========================================================================
// Core Multiplication Kernel
// ===========================================================================
//
// 5x52 field multiplication with inline secp256k1 reduction.
// p = 2^256 - 0x1000003D1, so 2^260 == R = 0x1000003D10 (mod p).
//
// Product columns 5-8 are reduced by multiplying by R (or R>>4, R<<12)
// and adding to columns 0-3. Columns processed out of order (3,4,0,1,2)
// to keep 128-bit accumulators from overflowing.
//
// With -mbmi2 -O3: compiles to MULX + ADD/ADC chains (verified).
// With always_inline: zero function-call overhead.

// CT/VT boundary note (read before assuming this is a "constant-time" primitive):
// fe52_mul_inner / fe52_sqr_inner are the DEFAULT 5x52 field multiply / square.
// The absence of a `_var` suffix does NOT make this a constant-time-HARDENED op.
// A 5x52 field multiply is straight-line __int128 arithmetic with NO data-dependent
// branches — it is inherently timing-invariant regardless of suffix. The `_var`
// twins (fe52_mul_inner_var / fe52_sqr_inner_var) are BYTE-IDENTICAL arithmetic and
// differ ONLY in codegen (FORCE_INLINE + optional monolithic ASM) suited to
// variable-time CONTEXTS where inlining is affordable. Neither variant leaks via
// timing. Consequently, calling the non-`_var` mul/square from a VERIFY path (e.g.
// build_glv52_table_zr's GLV precompute) is CORRECT — it is NOT "CT on verify".
// The real CT-vs-VT boundary is the SCALAR-MUL algorithm (fixed-window cmov for
// secrets vs wNAF/GLV for public data); verify already uses variable-time wNAF.
// Measured 2026-06-15: routing the verify table build to `_var` gives 0 speedup
// under LTO (GCC already emits MULX/ADCX/ADOX from __int128) — kb GLV52-VAR-TABLE-001.
//
// SUPERSEDED as an instruction, kept for the reasoning. This block used to say
// "Do NOT use SECP256K1_FE52_FORCE_INLINE (always_inline) here". The A/B below
// contradicted it on x86-64 and then on arm64, and the kernels are now
// always_inline everywhere this header compiles. Read the "Field-kernel
// inlining policy" block further down for the current rule.
//
// The optimize("O2") attribute this paragraph used to explain is gone with the
// out-of-line path: always_inline means the body is compiled at the caller's
// optimization level, so there is no out-of-line function left for an
// attribute to apply to.
//
// That attribute is GCC-only in effect. Clang does not implement optimize():
// it emits "unknown attribute 'optimize' ignored [-Wunknown-attributes]" and
// compiles as if only noinline were written, so on clang the Debug/coverage
// argument above does not apply -- the kernel is simply left out of line at
// whatever level the TU is built. Measured 2026-09-06 on this tree: clang-17
// --target=aarch64-linux-gnu -mcpu=apple-m1 -O3 produces byte-identical
// assembly with the clause and with plain noinline, while aarch64 gcc-13 at
// -O0 keeps the kernel at 494 asm lines instead of the 3029 the force-inline
// path produces. No fe52 kernel carries that clause any more -- the rule now
// applies only to the fe26 kernels in src/cpu/src/field_26.cpp, which are still
// out of line and therefore give clang plain noinline and keep the optimize
// clause for GCC, a codegen no-op on both.
// Instruction mix, disassembled from a -O3 -march=native GCC 14.2 build
// (experiments/representation_search). 228 instructions:
//     31  multiplies        13.6%
//     29  carry chain       12.7%   (adcx/adox/adc/sbb)
//     32  plain add/sub/lea 14.0%
//     17  shifts             7.5%
//     19  and/or/xor         8.3%
//     98  mov/push/pop      43.0%   (mov alone is 80, plus 6 push / 6 pop)
// 31 MULX at one per cycle is a 31-cycle floor; the measured 12.43 ns
// throughput is about 58 cycles at 4.7 GHz, so the kernel is NOT
// multiply-bound -- the remaining ~27 cycles are the serial carry/fold chain.
//
// The optimize("O2") below costs NOTHING on x86-64: rebuilt with
// optimize("O3") the two kernels are BYTE-IDENTICAL -- same 228/164
// instructions, same 31/21 multiplies, same 98/70 movs, same 12 spills. The
// attribute is doing exactly what its comment says (keeping Debug and coverage
// off O0) and is not capping Release performance. Checked so nobody re-raises
// it; do not "fix" this without re-measuring.

// ===========================================================================
// Field-kernel inlining policy
// ===========================================================================
// fe52_mul_inner and fe52_sqr_inner carried __attribute__((optimize("O2"),
// noinline)). Two separate blockers were stacked there: noinline, and the
// optimize() attribute, which on GCC also prevents inlining into a caller
// compiled with different options.
//
// libsecp256k1 v0.8.0 (PR #1859) force-inlined the equivalent routines and
// reported 0.6-11% on GCC/MSVC. Measured here against v0.8.0 on an i5-14400F
// (GCC 14.2, performance governor, turbo off, cpu0, nice -20, warm run vs warm
// run, libsecp/OpenSSL rows as the control at +0.01% median drift):
//   90 of 104 engine operations >= 500 ns improved by more than 2%, 1 regressed.
//   ECDSA verify vs libsecp v0.8.0 went 0.92x -> 1.00x, Schnorr verify
//   0.93x -> 1.01x, CT ECDSA sign 1.28x -> 1.35x, CT Schnorr sign 1.19x -> 1.27x.
// The gain is not in the multiply itself -- field_mul and field_sqr are
// unchanged to 0.00% in both libraries -- it is that removing the call boundary
// lets the caller schedule the 64x64->128 arithmetic alongside its own work.
//
// The size cost is real and is stated with the ARM64 table below.
//
// There is no longer a macro to set. It used to be settable per build, which
// was also an ODR hazard: FieldElement52::operator* and friends are
// always_inline external-linkage inlines whose bodies call these kernels, so a
// binary built half one way and half the other was a silent mismatch rather
// than a diagnostic. One shape everywhere removes that failure mode.
//
// The kernels are always_inline on every target that compiles this header.
//
// This used to be UFSECP_FE52_FORCE_INLINE_KERNELS, on for x86-64 and off
// everywhere else, with the note above asking for a warm-vs-warm A/B on real
// ARM64 hardware before flipping the default. That A/B has now been run, on a
// Rockchip RK3588 Cortex-A76 over adb, governor pinned to performance, three
// interleaved rounds, cpu7 (big core):
//
//     op                 noinline            always_inline        delta
//     fe52_sqr           72.03/72.05/72.32   66.53/66.57/66.59    -7.7%
//     ecdsa_verify       153931/154102/...   148803/148855/...    -3.4%
//     scalar_mul k*P     20658/20560/20550   20152/20167/20164    -2.0%
//     ecdsa_sign         63513/63557/63569   62239/62267/62283    -2.0%
//     fe52_mul           99.85/99.91/100.23  98.45/98.51/98.53    -1.5%
//     generator_mul k*G  2701/2706/2699      2699/2701/2702       ~0%
//
// Non-overlapping ranges on the first four. Smaller than the x86-64 result (90
// of 104 ops above 2%) but the same direction, so there is no target left where
// the flag was measured to be worth keeping off, and the two-configuration ODR
// hazard described above goes away with it.
//
// Independently confirmed on Apple silicon by the reporter of issue #336
// (craigraw), M5 Max / Apple clang 21, BIP-352 scan over 10,356,829 rows,
// 18 callers, non-LTO: 14.04-14.52s off -> 12.40-12.83s on, against a
// re-measured v3.68.0 baseline of 12.3-12.7s. The kernels left the leaf table
// exactly as the x86-64 result predicted, and the consumer-side size cost was
// +1.2% on their linked extension.
//
// Re-confirmed on the SHIPPED default with no define set anywhere (dev
// 2e9bf5ba, same protocol and machine): batch 12.53-12.65s, per-row
// 13.12-13.38s, instructions retired 6.49T / 6.55T -- matching the
// flag-injected legs to three digits, so the source-level always_inline and a
// -D on the command line produce the same code on that compiler.
//
// RESIDUAL, recorded because it is real: the BATCH path is at parity with
// v3.68.0 (12.53-12.65s vs 12.3-12.7s, ranges overlap; +1.1% instructions).
// The PER-ROW path is not -- 13.12-13.38s against the same baseline, ranges
// that do NOT overlap, so roughly 5% of user time is still unaccounted for on
// the old API. The reporter adopted the batch path and closed the issue on
// that basis. Anyone chasing the last 5% starts here, not from zero.
//
// COST: libfastsecp256k1.a grows 14.84% on x86-64 and 22.4% on arm64
// (18.77 MB -> 22.98 MB, measured on the same NDK build). That is the trade.
//
// Targets without __int128 (ESP32/STM32/Emscripten, where point.hpp does not
// include field_52.hpp) never compile this header, so they are unaffected.
// RISC-V has not been measured, but SECP256K1_RISCV_FE52_V1 routes it to
// hand-written assembly kernels below rather than this C++ body.

// ALIASING CONTRACT: r, a and b must not alias. That is stricter than
// libsecp256k1, which permits r == a, and it is kept deliberately: relaxing it so
// the in-place wrappers could write through measured +1.5% on scalar_mul (k*P),
// whose time is 39% jac52_double_coords -- a pure by-value path where the
// RESTRICT promise is worth real scheduling freedom.
//
// The copy that DOES cost time is not here. `*this = *this * rhs` is free when
// the object is a local, because SROA scalarises it into registers. It is a real
// 40-byte round trip through memory when the object is addressable -- a comb
// table entry, a struct member reached through a pointer. Removing four of those
// on the constant-time path (ct_point.cpp's global-Z rescales) measured
// -8.9% on ct::generator_mul and -6.4% on ct::ecdsa_sign. Look for the pattern
// at the CALL SITES, not in these wrappers.
SECP256K1_FE52_FORCE_INLINE
void fe52_mul_inner(std::uint64_t* SECP256K1_RESTRICT r,
                    const std::uint64_t* SECP256K1_RESTRICT a,
                    const std::uint64_t* SECP256K1_RESTRICT b) noexcept {
#if defined(SECP256K1_RISCV_FE52_V1)
    // RISC-V: Comba 5x52 multiply with integrated reduction in asm.
    // On U74 in-order core, explicit register scheduling + carry hiding
    // outperforms __int128 C++ (which Clang compiles to MUL/MULHU pairs
    // with suboptimal register allocation for 25+ multiplications).
    fe52_mul_inner_riscv64(r, a, b);
#elif 0 // MONOLITHIC_MUL_ASM: Disabled -- with -march=native, Clang __int128
      // already emits optimal MULX+ADCX/ADOX code. The inline asm prevents
      // cross-operation scheduling and increases register pressure (~30% slower
      // point_add when enabled). Kept for reference/non-native builds.
    // ========================================================================
    // Monolithic x86-64 MULX + ADCX/ADOX field multiply (single asm block)
    // ========================================================================
    // Single asm block = ZERO optimization barriers between columns.
    // ADCX/ADOX dual carry chains enable ILP in columns 1 & 2.
    //
    // Register layout — ALL clobbered registers are volatile on Win64:
    //   [a0]-[a4] = a limbs (read-only inputs, compiler picks registers)
    //   [bp]      = b pointer (read-only input)
    //   r8        = d_lo accumulator (volatile, clobbered)
    //   r9        = d_hi accumulator (volatile, clobbered)
    //   r10       = c_lo accumulator (volatile, clobbered)
    //   r11       = c_hi accumulator (volatile, clobbered)
    //   rdx       = MULX source (volatile, clobbered)
    //   rax       = MULX low / scratch (volatile, clobbered)
    //   rcx       = MULX high / scratch (volatile, clobbered)
    //   rbp,rsi,rbx,rdi,r12-r15 = FREE for compiler (not touched by asm)
    // ========================================================================
    std::uint64_t out0, out1, out2, out3 = 0, out4 = 0;
    const std::uint64_t a0_v = a[0], a1_v = a[1], a2_v = a[2];
    const std::uint64_t a3_v = a[3], a4_v = a[4];
    __asm__ __volatile__ (
        // ---- Column 3 + reduced column 8 ----
        "xorl %%r8d, %%r8d\n\t"                // d_lo=0, clears CF+OF
        "xorl %%r9d, %%r9d\n\t"                // d_hi=0

        "movq %[a0], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c = a4*b4
        "movq %[a4], %%rdx\n\t"
        "mulxq 32(%[bp]), %%r10, %%r11\n\t"

        // d += R52 * c_lo
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"
        // c >>= 64
        "movq %%r11, %%r10\n\t"

        // t3 = d & M52 → store to out3; d >>= 52
        "movq %%r8, %%rax\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rcx\n\t"
        "andq %%rcx, %%rax\n\t"
        "movq %%rax, %[o3]\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 4 + column 8 carry ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // d += (R52 << 12) * c_lo
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"

        // t4_full = d & M52 → r10; d >>= 52
        "movq %%r8, %%r10\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 0 + reduced column 5 ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // u0 = ((d & M52) << 4) | (t4_full >> 48)
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "shlq $4, %%rcx\n\t"
        "movq %%r10, %%rax\n\t"
        "shrq $48, %%rax\n\t"
        "orq %%rax, %%rcx\n\t"
        // t4 = t4_full & M48 → store to out4
        "movq $0xFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        // c = a0*b0 + u0 * (R52 >> 4)
        "movq %[a0], %%rdx\n\t"
        "mulxq (%[bp]), %%r10, %%r11\n\t"
        "movabsq $0x1000003D1, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[0] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o0]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 1 + reduced column 6 (dual chain) ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c += (d & M52) * R52; d >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[1] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o1]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 2 + reduced column 7 (dual chain) ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"

        // c += R52 * d_lo; d = d_hi
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "movq %%r9, %%r8\n\t"
        "xorl %%r9d, %%r9d\n\t"

        // r[2] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o2]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Finalize columns 3 and 4 ----
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "addq %[o3], %%r10\n\t"
        "adcq $0, %%r11\n\t"

        // r[3] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o3]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"

        // r[4] = c + t4
        "addq %[o4], %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        : [o0] "=m"(out0), [o1] "=m"(out1), [o2] "=m"(out2),
          [o3] "+m"(out3), [o4] "+m"(out4)
        : [a0] "r"(a0_v), [a1] "r"(a1_v), [a2] "r"(a2_v),
          [a3] "r"(a3_v), [a4] "r"(a4_v), [bp] "r"(b)
        : "rax", "rcx", "rdx", "r8", "r9", "r10", "r11", "cc", "memory"
    );
    r[0] = out0; r[1] = out1; r[2] = out2; r[3] = out3; r[4] = out4;
#elif 0 // INLINE_ADX disabled: asm barriers prevent ILP, __int128 is 6% faster
    // ------------------------------------------------------------------
    // x86-64 inline MULX + ADCX/ADOX dual carry chain path (OPT-IN)
    // NOTE: opt-in only. In benchmarks, the overhead of asm-block
    // optimization barriers outweighs the ADCX/ADOX parallel benefit.
    // The __int128 fallback lets the compiler schedule across column
    // boundaries, giving ~6% better throughput on Rocket Lake.
    // ------------------------------------------------------------------
    // ADCX uses CF flag, ADOX uses OF flag -- truly independent chains.
    // When both c and d accumulators accumulate products in the same
    // column, we interleave ADCX (d) and ADOX (c) to overlap execution.
    //
    // High-word carry invariant: sum of N products where each product
    // < 2^104 (52x52 bits) gives total < N*2^104. For N<=5:
    // 5*2^104 < 2^107 < 2^128. The 64-bit high word never overflows,
    // so carry-out from adcx/adox on the high part is always 0.
    // This keeps the continuous flag chain correct.
    //
    // Reduction multiplies between columns use __int128 C code (single
    // MULX+ADD+ADC pair, compiler-optimal for isolated operations).
    // ------------------------------------------------------------------
    using u128 = ::secp256k1::detail::u128_compat;
    std::uint64_t d_lo = 0, d_hi = 0;
    std::uint64_t c_lo = 0, c_hi = 0;
    std::uint64_t t3, t4, tx, u0;
    std::uint64_t sl, sh;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    // d = a0*b3 + a1*b2 + a2*b1 + a3*b0  (4 products, ADCX/CF)
    // c = a4*b4                            (1 product, ADOX/OF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // d += R52 * (uint64_t)c
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)R52 * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    c_lo = c_hi; c_hi = 0;
    t3 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;

    // -- Column 4 + column 8 carry -----------------------------------
    // d += a0*b4 + a1*b3 + a2*b2 + a3*b1 + a4*b0  (5 products, ADCX only)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // d += (R52 << 12) * c_lo  (c_lo carries column 3's c_hi)
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)(R52 << 12) * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    t4 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    // c = a0*b0                            (1 product, ADOX/OF)
    // d += a1*b4 + a2*b3 + a3*b2 + a4*b1  (4 products, ADCX/CF)
    c_lo = 0; c_hi = 0;
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    u0 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    u0 = (u0 << 4) | tx;
    // c += u0 * (R52 >> 4)
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)u0 * (R52 >> 4);
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[0] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    // c += a0*b1 + a1*b0              (2 products, ADOX/OF)
    // d += a2*b4 + a3*b3 + a4*b2      (3 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // c += ((uint64_t)d & M52) * R52
    { std::uint64_t d_masked = d_lo & M52;
      u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)d_masked * R52;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    r[1] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    // c += a0*b2 + a1*b1 + a2*b0      (3 products, ADOX/OF)
    // d += a3*b4 + a4*b3              (2 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // c += R52 * (uint64_t)d
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)R52 * d_lo;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = d_hi; d_hi = 0;   // d >>= 64
    r[2] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)(R52 << 12) * d_lo;
      cv += t3;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[3] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;
    c_lo += t4;
    r[4] = c_lo;
#else
    // Pointer-accumulation Comba (libsecp int128_struct idiom). On MSVC cl / wasm the
    // u128 accumulator is a struct: keeping ONE named c/d mutated in place by void
    // helpers lets the optimizer hold {lo,hi} in a register pair across the whole
    // column, instead of materializing a fresh 16-byte temporary per operator+ in a
    // value-chain (d = p0+p1+p2+p3) — those temporaries spill under the register
    // pressure of an inlined point op, which is exactly why the prior operator-chain
    // version lost to libsecp IN CONTEXT despite winning the isolated micro-bench.
    // On native __int128 the helpers ARE the operator forms — identical codegen.
    // Arithmetic is byte-for-byte the same as the operator chain it replaces, and the
    // carry (r->lo < lo) is data-independent, so the CT mul stays constant-time.
    using u128 = ::secp256k1::detail::u128_compat;
    using ::secp256k1::detail::u128_mul;
    using ::secp256k1::detail::u128_accum_mul;
    using ::secp256k1::detail::u128_accum_u64;
    u128 c, d;
    std::uint64_t t3 = 0, t4 = 0, tx = 0, u0 = 0;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    u128_mul(&d, a0, b[3]);
    u128_accum_mul(&d, a1, b[2]);
    u128_accum_mul(&d, a2, b[1]);
    u128_accum_mul(&d, a3, b[0]);
    u128_mul(&c, a4, b[4]);
    u128_accum_mul(&d, R52, (std::uint64_t)c);
    c >>= 64;
    t3 = (std::uint64_t)d & M52;
    d >>= 52;

    // -- Column 4 + column 8 carry -----------------------------------
    u128_accum_mul(&d, a0, b[4]);
    u128_accum_mul(&d, a1, b[3]);
    u128_accum_mul(&d, a2, b[2]);
    u128_accum_mul(&d, a3, b[1]);
    u128_accum_mul(&d, a4, b[0]);
    u128_accum_mul(&d, (R52 << 12), (std::uint64_t)c);
    t4 = (std::uint64_t)d & M52;
    d >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    u128_mul(&c, a0, b[0]);
    u128_accum_mul(&d, a1, b[4]);
    u128_accum_mul(&d, a2, b[3]);
    u128_accum_mul(&d, a3, b[2]);
    u128_accum_mul(&d, a4, b[1]);
    u0 = (std::uint64_t)d & M52;
    d >>= 52;
    u0 = (u0 << 4) | tx;
    u128_accum_mul(&c, u0, (R52 >> 4));
    r[0] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    u128_accum_mul(&c, a0, b[1]);
    u128_accum_mul(&c, a1, b[0]);
    u128_accum_mul(&d, a2, b[4]);
    u128_accum_mul(&d, a3, b[3]);
    u128_accum_mul(&d, a4, b[2]);
    u128_accum_mul(&c, (std::uint64_t)d & M52, R52);
    d >>= 52;
    r[1] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    u128_accum_mul(&c, a0, b[2]);
    u128_accum_mul(&c, a1, b[1]);
    u128_accum_mul(&c, a2, b[0]);
    u128_accum_mul(&d, a3, b[4]);
    u128_accum_mul(&d, a4, b[3]);
    u128_accum_mul(&c, R52, (std::uint64_t)d);
    d >>= 64;
    r[2] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    u128_accum_mul(&c, (R52 << 12), (std::uint64_t)d);
    u128_accum_u64(&c, t3);
    r[3] = (std::uint64_t)c & M52;
    c >>= 52;
    u128_accum_u64(&c, t4);
    r[4] = (std::uint64_t)c;
#endif // ARM64_FE52 / RISCV_FE52 / x64_ADX / generic (mul)
}

// ----- fe52_mul_inner_var: variable-time field multiply (verify only, ADCX/ADOX ASM) -----
SECP256K1_FE52_FORCE_INLINE
void fe52_mul_inner_var(std::uint64_t* SECP256K1_RESTRICT r,
                    const std::uint64_t* SECP256K1_RESTRICT a,
                    const std::uint64_t* SECP256K1_RESTRICT b) noexcept {
#if defined(SECP256K1_RISCV_FE52_V1)
    // RISC-V: Comba 5x52 multiply with integrated reduction in asm.
    // On U74 in-order core, explicit register scheduling + carry hiding
    // outperforms __int128 C++ (which Clang compiles to MUL/MULHU pairs
    // with suboptimal register allocation for 25+ multiplications).
    fe52_mul_inner_riscv64(r, a, b);
#elif defined(SECP256K1_HAS_ASM) && defined(__GNUC__) && !defined(__clang__) && defined(__x86_64__) \
      && !defined(LLVM_PROFILE_ENABLED) \
      && !defined(__SANITIZE_ADDRESS__) && !defined(__SANITIZE_THREAD__) && !defined(__SANITIZE_MEMORY__)
      // Monolithic MULX+ADCX/ADOX ASM for GCC x86-64 Release builds.
      // Guards: coverage instrumentation (LLVM_PROFILE_ENABLED) and sanitizers
      // inject calls between asm statements that clobber EFLAGS (CF/OF), breaking
      // the ADCX/ADOX dual-carry chains. Fall through to __int128 on those builds.
      // This is the same guard pattern used in ct_field.cpp for add256/sub256.
    // ========================================================================
    // Monolithic x86-64 MULX + ADCX/ADOX field multiply (single asm block)
    // ========================================================================
    // Single asm block = ZERO optimization barriers between columns.
    // ADCX/ADOX dual carry chains enable ILP in columns 1 & 2.
    //
    // Register layout — ALL clobbered registers are volatile on Win64:
    //   [a0]-[a4] = a limbs (read-only inputs, compiler picks registers)
    //   [bp]      = b pointer (read-only input)
    //   r8        = d_lo accumulator (volatile, clobbered)
    //   r9        = d_hi accumulator (volatile, clobbered)
    //   r10       = c_lo accumulator (volatile, clobbered)
    //   r11       = c_hi accumulator (volatile, clobbered)
    //   rdx       = MULX source (volatile, clobbered)
    //   rax       = MULX low / scratch (volatile, clobbered)
    //   rcx       = MULX high / scratch (volatile, clobbered)
    //   rbp,rsi,rbx,rdi,r12-r15 = FREE for compiler (not touched by asm)
    // ========================================================================
    std::uint64_t out0, out1, out2, out3 = 0, out4 = 0;
    const std::uint64_t a0_v = a[0], a1_v = a[1], a2_v = a[2];
    const std::uint64_t a3_v = a[3], a4_v = a[4];
    __asm__ __volatile__ (
        // ---- Column 3 + reduced column 8 ----
        "xorl %%r8d, %%r8d\n\t"                // d_lo=0, clears CF+OF
        "xorl %%r9d, %%r9d\n\t"                // d_hi=0

        "movq %[a0], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c = a4*b4
        "movq %[a4], %%rdx\n\t"
        "mulxq 32(%[bp]), %%r10, %%r11\n\t"

        // d += R52 * c_lo
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"
        // c >>= 64
        "movq %%r11, %%r10\n\t"

        // t3 = d & M52 → store to out3; d >>= 52
        "movq %%r8, %%rax\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rcx\n\t"
        "andq %%rcx, %%rax\n\t"
        "movq %%rax, %[o3]\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 4 + column 8 carry ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // d += (R52 << 12) * c_lo
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"

        // t4_full = d & M52 → r10; d >>= 52
        "movq %%r8, %%r10\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 0 + reduced column 5 ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // u0 = ((d & M52) << 4) | (t4_full >> 48)
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "shlq $4, %%rcx\n\t"
        "movq %%r10, %%rax\n\t"
        "shrq $48, %%rax\n\t"
        "orq %%rax, %%rcx\n\t"
        // t4 = t4_full & M48 → store to out4
        "movq $0xFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        // c = a0*b0 + u0 * (R52 >> 4)
        "movq %[a0], %%rdx\n\t"
        "mulxq (%[bp]), %%r10, %%r11\n\t"
        "movabsq $0x1000003D1, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[0] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o0]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 1 + reduced column 6 (dual chain) ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c += (d & M52) * R52; d >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[1] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o1]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 2 + reduced column 7 (dual chain) ----
        "xorl %%eax, %%eax\n\t"
        "movq %[a0], %%rdx\n\t"
        "mulxq 16(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq 32(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq 8(%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "movq %[a4], %%rdx\n\t"
        "mulxq 24(%[bp]), %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq (%[bp]), %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"

        // c += R52 * d_lo; d = d_hi
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "movq %%r9, %%r8\n\t"
        "xorl %%r9d, %%r9d\n\t"

        // r[2] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o2]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Finalize columns 3 and 4 ----
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "addq %[o3], %%r10\n\t"
        "adcq $0, %%r11\n\t"

        // r[3] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o3]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"

        // r[4] = c + t4
        "addq %[o4], %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        : [o0] "=m"(out0), [o1] "=m"(out1), [o2] "=m"(out2),
          [o3] "+m"(out3), [o4] "+m"(out4)
        : [a0] "r"(a0_v), [a1] "r"(a1_v), [a2] "r"(a2_v),
          [a3] "r"(a3_v), [a4] "r"(a4_v), [bp] "r"(b)
        : "rax", "rcx", "rdx", "r8", "r9", "r10", "r11", "cc", "memory"
    );
    r[0] = out0; r[1] = out1; r[2] = out2; r[3] = out3; r[4] = out4;
#elif 0 // INLINE_ADX disabled: asm barriers prevent ILP, __int128 is 6% faster
    // ------------------------------------------------------------------
    // x86-64 inline MULX + ADCX/ADOX dual carry chain path (OPT-IN)
    // NOTE: opt-in only. In benchmarks, the overhead of asm-block
    // optimization barriers outweighs the ADCX/ADOX parallel benefit.
    // The __int128 fallback lets the compiler schedule across column
    // boundaries, giving ~6% better throughput on Rocket Lake.
    // ------------------------------------------------------------------
    // ADCX uses CF flag, ADOX uses OF flag -- truly independent chains.
    // When both c and d accumulators accumulate products in the same
    // column, we interleave ADCX (d) and ADOX (c) to overlap execution.
    //
    // High-word carry invariant: sum of N products where each product
    // < 2^104 (52x52 bits) gives total < N*2^104. For N<=5:
    // 5*2^104 < 2^107 < 2^128. The 64-bit high word never overflows,
    // so carry-out from adcx/adox on the high part is always 0.
    // This keeps the continuous flag chain correct.
    //
    // Reduction multiplies between columns use __int128 C code (single
    // MULX+ADD+ADC pair, compiler-optimal for isolated operations).
    // ------------------------------------------------------------------
    using u128 = ::secp256k1::detail::u128_compat;
    std::uint64_t d_lo = 0, d_hi = 0;
    std::uint64_t c_lo = 0, c_hi = 0;
    std::uint64_t t3, t4, tx, u0;
    std::uint64_t sl, sh;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    // d = a0*b3 + a1*b2 + a2*b1 + a3*b0  (4 products, ADCX/CF)
    // c = a4*b4                            (1 product, ADOX/OF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // d += R52 * (uint64_t)c
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)R52 * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    c_lo = c_hi; c_hi = 0;
    t3 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;

    // -- Column 4 + column 8 carry -----------------------------------
    // d += a0*b4 + a1*b3 + a2*b2 + a3*b1 + a4*b0  (5 products, ADCX only)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // d += (R52 << 12) * c_lo  (c_lo carries column 3's c_hi)
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)(R52 << 12) * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    t4 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    // c = a0*b0                            (1 product, ADOX/OF)
    // d += a1*b4 + a2*b3 + a3*b2 + a4*b1  (4 products, ADCX/CF)
    c_lo = 0; c_hi = 0;
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    u0 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    u0 = (u0 << 4) | tx;
    // c += u0 * (R52 >> 4)
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)u0 * (R52 >> 4);
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[0] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    // c += a0*b1 + a1*b0              (2 products, ADOX/OF)
    // d += a2*b4 + a3*b3 + a4*b2      (3 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // c += ((uint64_t)d & M52) * R52
    { std::uint64_t d_masked = d_lo & M52;
      u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)d_masked * R52;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    r[1] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    // c += a0*b2 + a1*b1 + a2*b0      (3 products, ADOX/OF)
    // d += a3*b4 + a4*b3              (2 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq 16(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq 32(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq 8(%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq 24(%[bp]), %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq (%[bp]), %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4),
          [bp] "r"(b)
        : "rdx", "rcx", "cc"
    );
    // c += R52 * (uint64_t)d
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)R52 * d_lo;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = d_hi; d_hi = 0;   // d >>= 64
    r[2] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)(R52 << 12) * d_lo;
      cv += t3;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[3] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;
    c_lo += t4;
    r[4] = c_lo;
#else
    // Pointer-accumulation Comba (libsecp int128_struct idiom). On MSVC cl / wasm the
    // u128 accumulator is a struct: keeping ONE named c/d mutated in place by void
    // helpers lets the optimizer hold {lo,hi} in a register pair across the whole
    // column, instead of materializing a fresh 16-byte temporary per operator+ in a
    // value-chain (d = p0+p1+p2+p3) — those temporaries spill under the register
    // pressure of an inlined point op, which is exactly why the prior operator-chain
    // version lost to libsecp IN CONTEXT despite winning the isolated micro-bench.
    // On native __int128 the helpers ARE the operator forms — identical codegen.
    // Arithmetic is byte-for-byte the same as the operator chain it replaces, and the
    // carry (r->lo < lo) is data-independent, so the CT mul stays constant-time.
    using u128 = ::secp256k1::detail::u128_compat;
    using ::secp256k1::detail::u128_mul;
    using ::secp256k1::detail::u128_accum_mul;
    using ::secp256k1::detail::u128_accum_u64;
    u128 c, d;
    std::uint64_t t3 = 0, t4 = 0, tx = 0, u0 = 0;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    u128_mul(&d, a0, b[3]);
    u128_accum_mul(&d, a1, b[2]);
    u128_accum_mul(&d, a2, b[1]);
    u128_accum_mul(&d, a3, b[0]);
    u128_mul(&c, a4, b[4]);
    u128_accum_mul(&d, R52, (std::uint64_t)c);
    c >>= 64;
    t3 = (std::uint64_t)d & M52;
    d >>= 52;

    // -- Column 4 + column 8 carry -----------------------------------
    u128_accum_mul(&d, a0, b[4]);
    u128_accum_mul(&d, a1, b[3]);
    u128_accum_mul(&d, a2, b[2]);
    u128_accum_mul(&d, a3, b[1]);
    u128_accum_mul(&d, a4, b[0]);
    u128_accum_mul(&d, (R52 << 12), (std::uint64_t)c);
    t4 = (std::uint64_t)d & M52;
    d >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    u128_mul(&c, a0, b[0]);
    u128_accum_mul(&d, a1, b[4]);
    u128_accum_mul(&d, a2, b[3]);
    u128_accum_mul(&d, a3, b[2]);
    u128_accum_mul(&d, a4, b[1]);
    u0 = (std::uint64_t)d & M52;
    d >>= 52;
    u0 = (u0 << 4) | tx;
    u128_accum_mul(&c, u0, (R52 >> 4));
    r[0] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    u128_accum_mul(&c, a0, b[1]);
    u128_accum_mul(&c, a1, b[0]);
    u128_accum_mul(&d, a2, b[4]);
    u128_accum_mul(&d, a3, b[3]);
    u128_accum_mul(&d, a4, b[2]);
    u128_accum_mul(&c, (std::uint64_t)d & M52, R52);
    d >>= 52;
    r[1] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    u128_accum_mul(&c, a0, b[2]);
    u128_accum_mul(&c, a1, b[1]);
    u128_accum_mul(&c, a2, b[0]);
    u128_accum_mul(&d, a3, b[4]);
    u128_accum_mul(&d, a4, b[3]);
    u128_accum_mul(&c, R52, (std::uint64_t)d);
    d >>= 64;
    r[2] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    u128_accum_mul(&c, (R52 << 12), (std::uint64_t)d);
    u128_accum_u64(&c, t3);
    r[3] = (std::uint64_t)c & M52;
    c >>= 52;
    u128_accum_u64(&c, t4);
    r[4] = (std::uint64_t)c;
#endif // ARM64_FE52 / RISCV_FE52 / x64_ADX / generic (mul)
}

// ===========================================================================
// Core Squaring Kernel (symmetry-optimized)
// ===========================================================================
//
// Uses a[i]*a[j] == a[j]*a[i] symmetry to halve cross-product count.
// Cross-products computed once and doubled via (a[i]*2) trick.

// always_inline, same as fe52_mul_inner and for the same measured reason (see
// the "Field-kernel inlining policy" block above). Disassembled at
// -O3 -march=native: 164 instructions, 21 multiplies (12.8%), 70 mov/push/pop
// (42.7%) -- the same data-movement-dominated shape.
SECP256K1_FE52_FORCE_INLINE
void fe52_sqr_inner(std::uint64_t* SECP256K1_RESTRICT r,
                    const std::uint64_t* SECP256K1_RESTRICT a) noexcept {
#if defined(SECP256K1_RISCV_FE52_V1)
    // RISC-V: Symmetry-optimized squaring in asm.
    // Cross-products doubled via shift, halving multiplication count.
    fe52_sqr_inner_riscv64(r, a);
#elif 0 // MONOLITHIC_SQR_ASM: Disabled -- same rationale as mul ASM above.
    // ========================================================================
    // Monolithic x86-64 MULX + ADCX/ADOX field squaring (single asm block)
    // ========================================================================
    // Cross-products doubled via LEA (flags-neutral), only 15 MULXes vs 25.
    // ALL clobbered registers are volatile on Win64 (r8-r11, rax, rcx, rdx).
    // ========================================================================
    std::uint64_t out0, out1, out2, out3 = 0, out4 = 0;
    const std::uint64_t a0_v = a[0], a1_v = a[1], a2_v = a[2];
    const std::uint64_t a3_v = a[3], a4_v = a[4];
    __asm__ __volatile__ (
        // ---- Column 3 + reduced column 8 ----
        // d = 2*a0*a3 + 2*a1*a2; c = a4^2
        "xorl %%r8d, %%r8d\n\t"
        "xorl %%r9d, %%r9d\n\t"

        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c = a4*a4
        "movq %[a4], %%rdx\n\t"
        "mulxq %[a4], %%r10, %%r11\n\t"

        // d += R52 * c_lo
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"
        // c >>= 64
        "movq %%r11, %%r10\n\t"

        // t3 = d & M52; d >>= 52
        "movq %%r8, %%rax\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rcx\n\t"
        "andq %%rcx, %%rax\n\t"
        "movq %%rax, %[o3]\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 4 ----
        // d += 2*a0*a4 + 2*a1*a3 + a2^2
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // d += (R52 << 12) * c_lo
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"

        // t4_full = d & M52; d >>= 52
        "movq %%r8, %%r10\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 0 + reduced column 5 ----
        // c = a0^2; d += 2*a1*a4 + 2*a2*a3
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // u0 = ((d & M52) << 4) | (t4_full >> 48)
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "shlq $4, %%rcx\n\t"
        "movq %%r10, %%rax\n\t"
        "shrq $48, %%rax\n\t"
        "orq %%rax, %%rcx\n\t"
        // t4 = t4_full & M48
        "movq $0xFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        // c = a0*a0 + u0 * (R52 >> 4)
        "movq %[a0], %%rdx\n\t"
        "mulxq %[a0], %%r10, %%r11\n\t"
        "movabsq $0x1000003D1, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[0] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o0]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 1 + reduced column 6 (dual chain) ----
        // c += 2*a0*a1 (ADOX); d += 2*a2*a4 + a3^2 (ADCX)
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a1], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "leaq (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c += (d & M52) * R52; d >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[1] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o1]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 2 + reduced column 7 (dual chain) ----
        // c += 2*a0*a2 + a1^2 (ADOX); d += 2*a3*a4 (ADCX)
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "leaq (%[a3], %[a3]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq %[a1], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"

        // c += R52 * d_lo; d = d_hi
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "movq %%r9, %%r8\n\t"
        "xorl %%r9d, %%r9d\n\t"

        // r[2] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o2]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Finalize columns 3 and 4 ----
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "addq %[o3], %%r10\n\t"
        "adcq $0, %%r11\n\t"

        // r[3] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o3]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"

        // r[4] = c + t4
        "addq %[o4], %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        : [o0] "=m"(out0), [o1] "=m"(out1), [o2] "=m"(out2),
          [o3] "+m"(out3), [o4] "+m"(out4)
        : [a0] "r"(a0_v), [a1] "r"(a1_v), [a2] "r"(a2_v),
          [a3] "r"(a3_v), [a4] "r"(a4_v)
        : "rax", "rcx", "rdx", "r8", "r9", "r10", "r11", "cc", "memory"
    );
    r[0] = out0; r[1] = out1; r[2] = out2; r[3] = out3; r[4] = out4;
#elif 0 // INLINE_ADX disabled: asm barriers prevent ILP, __int128 is 6% faster
    // ------------------------------------------------------------------
    // x86-64 inline MULX + ADCX/ADOX squaring (OPT-IN) -- see mul note
    // ------------------------------------------------------------------
    // Cross-products doubled via LEA (flags-neutral) then accumulated
    // with ADCX/ADOX dual carry chains. Square terms use plain MULX.
    // Same high-word carry invariant as fe52_mul_inner (sum < 2^128).
    // ------------------------------------------------------------------
    using u128 = ::secp256k1::detail::u128_compat;
    std::uint64_t d_lo = 0, d_hi = 0;
    std::uint64_t c_lo = 0, c_hi = 0;
    std::uint64_t t3, t4, tx, u0;
    std::uint64_t sl, sh;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    // d = (a0*2)*a3 + (a1*2)*a2   (2 cross-products, ADCX/CF)
    // c = a4*a4                    (1 square, ADOX/OF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)R52 * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    c_lo = c_hi; c_hi = 0;
    t3 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;

    // -- Column 4 ----------------------------------------------------
    // d += (a0*2)*a4 + (a1*2)*a3 + a2*a2  (3 products, ADCX only)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)(R52 << 12) * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    t4 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    // c = a0*a0                      (1 square, ADOX/OF)
    // d += (a1*2)*a4 + (a2*2)*a3     (2 cross-products, ADCX/CF)
    c_lo = 0; c_hi = 0;
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq %[a0], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "lea (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    u0 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    u0 = (u0 << 4) | tx;
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)u0 * (R52 >> 4);
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[0] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    // c += (a0*2)*a1                  (1 cross-product, ADOX/OF)
    // d += (a2*2)*a4 + a3*a3          (2 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a1], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { std::uint64_t d_masked = d_lo & M52;
      u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)d_masked * R52;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    r[1] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    // c += (a0*2)*a2 + a1*a1          (2 products, ADOX/OF)
    // d += (a3*2)*a4                  (1 cross-product, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a3], %[a3]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq %[a1], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)R52 * d_lo;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = d_hi; d_hi = 0;
    r[2] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)(R52 << 12) * d_lo;
      cv += t3;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[3] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;
    c_lo += t4;
    r[4] = c_lo;
#else
    // Pointer-accumulation Comba squaring (libsecp int128_struct idiom — see the mul
    // kernel above for the full rationale). One named c/d mutated in place; no per-term
    // 16-byte temporaries to spill. Each (ai*2) fits u64 (52-bit limb * 2 = 2^53), and
    // each product <2^106, so u64xu64 helpers are exact. Arithmetic-identical, CT-safe.
    using u128 = ::secp256k1::detail::u128_compat;
    using ::secp256k1::detail::u128_mul;
    using ::secp256k1::detail::u128_accum_mul;
    using ::secp256k1::detail::u128_accum_u64;
    u128 c, d;
    std::uint64_t t3 = 0, t4 = 0, tx = 0, u0 = 0;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    u128_mul(&d, a0 * 2, a3);
    u128_accum_mul(&d, a1 * 2, a2);
    u128_mul(&c, a4, a4);
    u128_accum_mul(&d, R52, (std::uint64_t)c);
    c >>= 64;
    t3 = (std::uint64_t)d & M52;
    d >>= 52;

    // -- Column 4 ----------------------------------------------------
    u128_accum_mul(&d, a0 * 2, a4);
    u128_accum_mul(&d, a1 * 2, a3);
    u128_accum_mul(&d, a2, a2);
    u128_accum_mul(&d, (R52 << 12), (std::uint64_t)c);
    t4 = (std::uint64_t)d & M52;
    d >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    u128_mul(&c, a0, a0);
    u128_accum_mul(&d, a1 * 2, a4);
    u128_accum_mul(&d, a2 * 2, a3);
    u0 = (std::uint64_t)d & M52;
    d >>= 52;
    u0 = (u0 << 4) | tx;
    u128_accum_mul(&c, u0, (R52 >> 4));
    r[0] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    u128_accum_mul(&c, a0 * 2, a1);
    u128_accum_mul(&d, a2 * 2, a4);
    u128_accum_mul(&d, a3, a3);
    u128_accum_mul(&c, (std::uint64_t)d & M52, R52);
    d >>= 52;
    r[1] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    u128_accum_mul(&c, a0 * 2, a2);
    u128_accum_mul(&c, a1, a1);
    u128_accum_mul(&d, a3 * 2, a4);
    u128_accum_mul(&c, R52, (std::uint64_t)d);
    d >>= 64;
    r[2] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    u128_accum_mul(&c, (R52 << 12), (std::uint64_t)d);
    u128_accum_u64(&c, t3);
    r[3] = (std::uint64_t)c & M52;
    c >>= 52;
    u128_accum_u64(&c, t4);
    r[4] = (std::uint64_t)c;
#endif // ARM64_FE52 / RISCV_FE52 / x64_ADX / generic (sqr)
}

// ----- fe52_sqr_inner_var: variable-time field square (verify only, ADCX/ADOX ASM) -----
SECP256K1_FE52_FORCE_INLINE
void fe52_sqr_inner_var(std::uint64_t* SECP256K1_RESTRICT r,
                    const std::uint64_t* SECP256K1_RESTRICT a) noexcept {
#if defined(SECP256K1_RISCV_FE52_V1)
    // RISC-V: Symmetry-optimized squaring in asm.
    // Cross-products doubled via shift, halving multiplication count.
    fe52_sqr_inner_riscv64(r, a);
#elif defined(SECP256K1_HAS_ASM) && defined(__GNUC__) && !defined(__clang__) && (defined(__x86_64__) || defined(_M_X64)) // MONOLITHIC_SQR_ASM: Disabled -- same rationale as mul ASM above.
    // ========================================================================
    // Monolithic x86-64 MULX + ADCX/ADOX field squaring (single asm block)
    // ========================================================================
    // Cross-products doubled via LEA (flags-neutral), only 15 MULXes vs 25.
    // ALL clobbered registers are volatile on Win64 (r8-r11, rax, rcx, rdx).
    // ========================================================================
    std::uint64_t out0, out1, out2, out3 = 0, out4 = 0;
    const std::uint64_t a0_v = a[0], a1_v = a[1], a2_v = a[2];
    const std::uint64_t a3_v = a[3], a4_v = a[4];
    __asm__ __volatile__ (
        // ---- Column 3 + reduced column 8 ----
        // d = 2*a0*a3 + 2*a1*a2; c = a4^2
        "xorl %%r8d, %%r8d\n\t"
        "xorl %%r9d, %%r9d\n\t"

        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c = a4*a4
        "movq %[a4], %%rdx\n\t"
        "mulxq %[a4], %%r10, %%r11\n\t"

        // d += R52 * c_lo
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"
        // c >>= 64
        "movq %%r11, %%r10\n\t"

        // t3 = d & M52; d >>= 52
        "movq %%r8, %%rax\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rcx\n\t"
        "andq %%rcx, %%rax\n\t"
        "movq %%rax, %[o3]\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 4 ----
        // d += 2*a0*a4 + 2*a1*a3 + a2^2
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a2], %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // d += (R52 << 12) * c_lo
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r10, %%rax, %%rcx\n\t"
        "addq %%rax, %%r8\n\t"
        "adcq %%rcx, %%r9\n\t"

        // t4_full = d & M52; d >>= 52
        "movq %%r8, %%r10\n\t"
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"

        // ---- Column 0 + reduced column 5 ----
        // c = a0^2; d += 2*a1*a4 + 2*a2*a3
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "leaq (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // u0 = ((d & M52) << 4) | (t4_full >> 48)
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "shlq $4, %%rcx\n\t"
        "movq %%r10, %%rax\n\t"
        "shrq $48, %%rax\n\t"
        "orq %%rax, %%rcx\n\t"
        // t4 = t4_full & M48
        "movq $0xFFFFFFFFFFFF, %%rax\n\t"
        "andq %%rax, %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        // c = a0*a0 + u0 * (R52 >> 4)
        "movq %[a0], %%rdx\n\t"
        "mulxq %[a0], %%r10, %%r11\n\t"
        "movabsq $0x1000003D1, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[0] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o0]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 1 + reduced column 6 (dual chain) ----
        // c += 2*a0*a1 (ADOX); d += 2*a2*a4 + a3^2 (ADCX)
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a1], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "leaq (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a3], %%rdx\n\t"
        "mulxq %[a3], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"

        // c += (d & M52) * R52; d >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r8, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "shrdq $52, %%r9, %%r8\n\t"
        "shrq $52, %%r9\n\t"
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%rcx, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"

        // r[1] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o1]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Column 2 + reduced column 7 (dual chain) ----
        // c += 2*a0*a2 + a1^2 (ADOX); d += 2*a3*a4 (ADCX)
        "xorl %%eax, %%eax\n\t"
        "leaq (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a2], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"
        "leaq (%[a3], %[a3]), %%rdx\n\t"
        "mulxq %[a4], %%rax, %%rcx\n\t"
        "adcxq %%rax, %%r8\n\t"
        "adcxq %%rcx, %%r9\n\t"
        "movq %[a1], %%rdx\n\t"
        "mulxq %[a1], %%rax, %%rcx\n\t"
        "adoxq %%rax, %%r10\n\t"
        "adoxq %%rcx, %%r11\n\t"

        // c += R52 * d_lo; d = d_hi
        "movabsq $0x1000003D10, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "movq %%r9, %%r8\n\t"
        "xorl %%r9d, %%r9d\n\t"

        // r[2] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o2]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"
        "shrq $52, %%r11\n\t"

        // ---- Finalize columns 3 and 4 ----
        "movabsq $0x1000003D10000, %%rdx\n\t"
        "mulxq %%r8, %%rax, %%rcx\n\t"
        "addq %%rax, %%r10\n\t"
        "adcq %%rcx, %%r11\n\t"
        "addq %[o3], %%r10\n\t"
        "adcq $0, %%r11\n\t"

        // r[3] = c & M52; c >>= 52
        "movq $0xFFFFFFFFFFFFF, %%rax\n\t"
        "movq %%r10, %%rcx\n\t"
        "andq %%rax, %%rcx\n\t"
        "movq %%rcx, %[o3]\n\t"
        "shrdq $52, %%r11, %%r10\n\t"

        // r[4] = c + t4
        "addq %[o4], %%r10\n\t"
        "movq %%r10, %[o4]\n\t"

        : [o0] "=m"(out0), [o1] "=m"(out1), [o2] "=m"(out2),
          [o3] "+m"(out3), [o4] "+m"(out4)
        : [a0] "r"(a0_v), [a1] "r"(a1_v), [a2] "r"(a2_v),
          [a3] "r"(a3_v), [a4] "r"(a4_v)
        : "rax", "rcx", "rdx", "r8", "r9", "r10", "r11", "cc", "memory"
    );
    r[0] = out0; r[1] = out1; r[2] = out2; r[3] = out3; r[4] = out4;
#elif 0 // INLINE_ADX disabled: asm barriers prevent ILP, __int128 is 6% faster
    // ------------------------------------------------------------------
    // x86-64 inline MULX + ADCX/ADOX squaring (OPT-IN) -- see mul note
    // ------------------------------------------------------------------
    // Cross-products doubled via LEA (flags-neutral) then accumulated
    // with ADCX/ADOX dual carry chains. Square terms use plain MULX.
    // Same high-word carry invariant as fe52_mul_inner (sum < 2^128).
    // ------------------------------------------------------------------
    using u128 = ::secp256k1::detail::u128_compat;
    std::uint64_t d_lo = 0, d_hi = 0;
    std::uint64_t c_lo = 0, c_hi = 0;
    std::uint64_t t3, t4, tx, u0;
    std::uint64_t sl, sh;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    // d = (a0*2)*a3 + (a1*2)*a2   (2 cross-products, ADCX/CF)
    // c = a4*a4                    (1 square, ADOX/OF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a4], %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)R52 * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    c_lo = c_hi; c_hi = 0;
    t3 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;

    // -- Column 4 ----------------------------------------------------
    // d += (a0*2)*a4 + (a1*2)*a3 + a2*a2  (3 products, ADCX only)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a2], %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 dv = ((u128)d_hi << 64) | d_lo;
      dv += (u128)(R52 << 12) * c_lo;
      d_lo = (std::uint64_t)dv; d_hi = (std::uint64_t)(dv >> 64); }
    t4 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    // c = a0*a0                      (1 square, ADOX/OF)
    // d += (a1*2)*a4 + (a2*2)*a3     (2 cross-products, ADCX/CF)
    c_lo = 0; c_hi = 0;
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "mov %[a0], %%rdx\n\t"
        "mulxq %[a0], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a1], %[a1]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "lea (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    u0 = d_lo & M52;
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    u0 = (u0 << 4) | tx;
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)u0 * (R52 >> 4);
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[0] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    // c += (a0*2)*a1                  (1 cross-product, ADOX/OF)
    // d += (a2*2)*a4 + a3*a3          (2 products, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a1], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a2], %[a2]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a3], %%rdx\n\t"
        "mulxq %[a3], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { std::uint64_t d_masked = d_lo & M52;
      u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)d_masked * R52;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = (d_lo >> 52) | (d_hi << 12); d_hi >>= 52;
    r[1] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    // c += (a0*2)*a2 + a1*a1          (2 products, ADOX/OF)
    // d += (a3*2)*a4                  (1 cross-product, ADCX/CF)
    __asm__ __volatile__(
        "xor %%ecx, %%ecx\n\t"
        "lea (%[a0], %[a0]), %%rdx\n\t"
        "mulxq %[a2], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        "lea (%[a3], %[a3]), %%rdx\n\t"
        "mulxq %[a4], %[sl], %[sh]\n\t"
        "adcx %[sl], %[dl]\n\t"
        "adcx %[sh], %[dh]\n\t"
        "mov %[a1], %%rdx\n\t"
        "mulxq %[a1], %[sl], %[sh]\n\t"
        "adox %[sl], %[cl]\n\t"
        "adox %[sh], %[ch]\n\t"
        : [dl] "+&r"(d_lo), [dh] "+&r"(d_hi),
          [cl] "+&r"(c_lo), [ch] "+&r"(c_hi),
          [sl] "=&r"(sl), [sh] "=&r"(sh)
        : [a0] "r"(a0), [a1] "r"(a1), [a2] "r"(a2), [a3] "r"(a3), [a4] "r"(a4)
        : "rdx", "rcx", "cc"
    );
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)R52 * d_lo;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    d_lo = d_hi; d_hi = 0;
    r[2] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    { u128 cv = ((u128)c_hi << 64) | c_lo;
      cv += (u128)(R52 << 12) * d_lo;
      cv += t3;
      c_lo = (std::uint64_t)cv; c_hi = (std::uint64_t)(cv >> 64); }
    r[3] = c_lo & M52;
    c_lo = (c_lo >> 52) | (c_hi << 12); c_hi >>= 52;
    c_lo += t4;
    r[4] = c_lo;
#else
    // Pointer-accumulation Comba squaring (libsecp int128_struct idiom — see the mul
    // kernel above for the full rationale). One named c/d mutated in place; no per-term
    // 16-byte temporaries to spill. Each (ai*2) fits u64 (52-bit limb * 2 = 2^53), and
    // each product <2^106, so u64xu64 helpers are exact. Arithmetic-identical, CT-safe.
    using u128 = ::secp256k1::detail::u128_compat;
    using ::secp256k1::detail::u128_mul;
    using ::secp256k1::detail::u128_accum_mul;
    using ::secp256k1::detail::u128_accum_u64;
    u128 c, d;
    std::uint64_t t3 = 0, t4 = 0, tx = 0, u0 = 0;
    const std::uint64_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3], a4 = a[4];

    // -- Column 3 + reduced column 8 ---------------------------------
    u128_mul(&d, a0 * 2, a3);
    u128_accum_mul(&d, a1 * 2, a2);
    u128_mul(&c, a4, a4);
    u128_accum_mul(&d, R52, (std::uint64_t)c);
    c >>= 64;
    t3 = (std::uint64_t)d & M52;
    d >>= 52;

    // -- Column 4 ----------------------------------------------------
    u128_accum_mul(&d, a0 * 2, a4);
    u128_accum_mul(&d, a1 * 2, a3);
    u128_accum_mul(&d, a2, a2);
    u128_accum_mul(&d, (R52 << 12), (std::uint64_t)c);
    t4 = (std::uint64_t)d & M52;
    d >>= 52;
    tx = (t4 >> 48); t4 &= (M52 >> 4);

    // -- Column 0 + reduced column 5 ---------------------------------
    u128_mul(&c, a0, a0);
    u128_accum_mul(&d, a1 * 2, a4);
    u128_accum_mul(&d, a2 * 2, a3);
    u0 = (std::uint64_t)d & M52;
    d >>= 52;
    u0 = (u0 << 4) | tx;
    u128_accum_mul(&c, u0, (R52 >> 4));
    r[0] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 1 + reduced column 6 ---------------------------------
    u128_accum_mul(&c, a0 * 2, a1);
    u128_accum_mul(&d, a2 * 2, a4);
    u128_accum_mul(&d, a3, a3);
    u128_accum_mul(&c, (std::uint64_t)d & M52, R52);
    d >>= 52;
    r[1] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Column 2 + reduced column 7 ---------------------------------
    u128_accum_mul(&c, a0 * 2, a2);
    u128_accum_mul(&c, a1, a1);
    u128_accum_mul(&d, a3 * 2, a4);
    u128_accum_mul(&c, R52, (std::uint64_t)d);
    d >>= 64;
    r[2] = (std::uint64_t)c & M52;
    c >>= 52;

    // -- Finalize columns 3 and 4 ------------------------------------
    u128_accum_mul(&c, (R52 << 12), (std::uint64_t)d);
    u128_accum_u64(&c, t3);
    r[3] = (std::uint64_t)c & M52;
    c >>= 52;
    u128_accum_u64(&c, t4);
    r[4] = (std::uint64_t)c;
#endif // ARM64_FE52 / RISCV_FE52 / x64_ADX / generic (sqr)
}

// ===========================================================================
// Weak Normalization (inline for half() hot path)
// ===========================================================================

SECP256K1_FE52_FORCE_INLINE
void fe52_normalize_weak(std::uint64_t* r) noexcept {
    std::uint64_t t0 = r[0], t1 = r[1], t2 = r[2], t3 = r[3], t4 = r[4];
    // Pass 1: propagate carries bottom-to-top to get true t4 value.
    // Required because our negate convention (1*(m+1)*P, not 2*(m+1)*P)
    // allows lower-limb carries that propagate to t4.
    t1 += (t0 >> 52); t0 &= M52;
    t2 += (t1 >> 52); t1 &= M52;
    t3 += (t2 >> 52); t2 &= M52;
    t4 += (t3 >> 52); t3 &= M52;
    // Fold t4 overflow: x * 2^256 == x * R (mod p)
    std::uint64_t const x = t4 >> 48;
    t4 &= M48;
    t0 += x * 0x1000003D1ULL;
    // Pass 2: re-propagate carry from fold
    t1 += (t0 >> 52); t0 &= M52;
    t2 += (t1 >> 52); t1 &= M52;
    t3 += (t2 >> 52); t2 &= M52;
    t4 += (t3 >> 52); t3 &= M52;
    r[0] = t0; r[1] = t1; r[2] = t2; r[3] = t3; r[4] = t4;
}

// ===========================================================================
// FieldElement52 Method Implementations (all force-inlined)
// ===========================================================================

// -- Multiplication -------------------------------------------------------

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::operator*(const FieldElement52& rhs) const noexcept {
    FieldElement52 r;
    fe52_mul_inner(r.n, n, rhs.n);
    return r;
}

// Variable-time-CONTEXT variant — identical arithmetic to the default above,
// FORCE_INLINE (+ optional ASM) for public/variable-time paths such as verify.
// "VERIFY only" is a codegen choice, NOT a security distinction: the default is
// equally branchless/timing-invariant. See the CT/VT boundary note at fe52_mul_inner.
SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::mul_var(const FieldElement52& rhs) const noexcept {
    FieldElement52 r;
    fe52_mul_inner_var(r.n, n, rhs.n);
    return r;
}
SECP256K1_FE52_FORCE_INLINE
void FieldElement52::mul_assign_var(const FieldElement52& rhs) noexcept {
    *this = mul_var(rhs);
}

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::square() const noexcept {
    FieldElement52 r;
    fe52_sqr_inner(r.n, n);
    return r;
}

// Variable-time-CONTEXT variant — identical arithmetic to the default above,
// FORCE_INLINE (+ optional ASM) for public/variable-time paths such as verify.
// "VERIFY only" is a codegen choice, NOT a security distinction: the default is
// equally branchless/timing-invariant. See the CT/VT boundary note at fe52_mul_inner.
SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::square_var() const noexcept {
    FieldElement52 r;
    fe52_sqr_inner_var(r.n, n);
    return r;
}
SECP256K1_FE52_FORCE_INLINE
void FieldElement52::square_inplace_var() noexcept {
    *this = square_var();
}

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::mul_assign(const FieldElement52& rhs) noexcept {
    *this = *this * rhs;
}

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::square_inplace() noexcept {
    *this = square();
}

// -- Lazy Addition (NO carry propagation!) --------------------------------

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::operator+(const FieldElement52& rhs) const noexcept {
    FieldElement52 r;
    r.n[0] = n[0] + rhs.n[0];
    r.n[1] = n[1] + rhs.n[1];
    r.n[2] = n[2] + rhs.n[2];
    r.n[3] = n[3] + rhs.n[3];
    r.n[4] = n[4] + rhs.n[4];
    return r;
}

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::add_assign(const FieldElement52& rhs) noexcept {
    n[0] += rhs.n[0];
    n[1] += rhs.n[1];
    n[2] += rhs.n[2];
    n[3] += rhs.n[3];
    n[4] += rhs.n[4];
}

// -- Negate: (M+1)*p - a -------------------------------------------------

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::negate(unsigned magnitude) const noexcept {
    using namespace fe52_constants;
    FieldElement52 r;
    const std::uint64_t m1 = static_cast<std::uint64_t>(magnitude) + 1ULL;
    r.n[0] = m1 * P0 - n[0];
    r.n[1] = m1 * P1 - n[1];
    r.n[2] = m1 * P2 - n[2];
    r.n[3] = m1 * P3 - n[3];
    r.n[4] = m1 * P4 - n[4];
    return r;
}

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::negate_assign(unsigned magnitude) noexcept {
    const std::uint64_t m1 = static_cast<std::uint64_t>(magnitude) + 1ULL;
    n[0] = m1 * P0 - n[0];
    n[1] = m1 * P1 - n[1];
    n[2] = m1 * P2 - n[2];
    n[3] = m1 * P3 - n[3];
    n[4] = m1 * P4 - n[4];
}

// -- Branchless conditional negate (magnitude 1) --------------------------
// sign_mask: 0 = keep original, -1 (0xFFFFFFFF) = negate.
// Uses XOR-select to avoid branches on unpredictable sign bits.
SECP256K1_FE52_FORCE_INLINE
void FieldElement52::conditional_negate_assign(std::int32_t sign_mask) noexcept {
    const auto mask = static_cast<std::uint64_t>(static_cast<std::int64_t>(sign_mask));
    // Compute negated limbs (magnitude 1: 2*P - n)
    const std::uint64_t neg0 = 2ULL * P0 - n[0];
    const std::uint64_t neg1 = 2ULL * P1 - n[1];
    const std::uint64_t neg2 = 2ULL * P2 - n[2];
    const std::uint64_t neg3 = 2ULL * P3 - n[3];
    const std::uint64_t neg4 = 2ULL * P4 - n[4];
    // Branchless select: mask=0 → keep n[i]; mask=~0 → use neg[i]
    n[0] ^= (n[0] ^ neg0) & mask;
    n[1] ^= (n[1] ^ neg1) & mask;
    n[2] ^= (n[2] ^ neg2) & mask;
    n[3] ^= (n[3] ^ neg3) & mask;
    n[4] ^= (n[4] ^ neg4) & mask;
}

// -- Weak Normalization (member) ------------------------------------------

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::normalize_weak() noexcept {
    fe52_normalize_weak(n);
}

// -- Half (a/2 mod p) -- branchless ---------------------------------------
// libsecp-style: mask trick avoids carry propagation entirely.
// If odd, add p; then right-shift by 1.  The mask is (-(t0 & 1)) >> 12
// which produces a 52-bit all-ones mask (0xFFFFFFFFFFFFF) when odd, 0 when even.
// Since P1=P2=P3 = M52 = 0xFFFFFFFFFFFFF, and the mask has exactly 52 set bits,
// adding mask to P1..P3 limbs can never exceed 2*M52 < 2^53 (fits in 64 bits).
// No carry propagation needed!

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::half() const noexcept {
    const std::uint64_t* src = n;
    const std::uint64_t one = 1ULL;
    const std::uint64_t mask = (0ULL - (src[0] & one)) >> 12;  // 52-bit mask if odd

    // Conditionally add p (limb-wise, no carry propagation needed)
    const std::uint64_t t0 = src[0] + (0xFFFFEFFFFFC2FULL & mask);
    const std::uint64_t t1 = src[1] + mask;       // P1 = M52 = mask
    const std::uint64_t t2 = src[2] + mask;       // P2 = M52 = mask
    const std::uint64_t t3 = src[3] + mask;       // P3 = M52 = mask
    const std::uint64_t t4 = src[4] + (mask >> 4); // P4 = 48-bit

    // Right shift by 1 (divide by 2)
    // MUST use + (not |): without carry propagation, t_i can exceed M52,
    // so bit 51 of (t_i >> 1) can be set, overlapping with (t_{i+1} & 1) << 51.
    // Addition correctly carries; OR would silently drop the carry.
    FieldElement52 r;
    r.n[0] = (t0 >> 1) + ((t1 & one) << 51);
    r.n[1] = (t1 >> 1) + ((t2 & one) << 51);
    r.n[2] = (t2 >> 1) + ((t3 & one) << 51);
    r.n[3] = (t3 >> 1) + ((t4 & one) << 51);
    r.n[4] = (t4 >> 1);
    return r;
}

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::half_assign() noexcept {
    const std::uint64_t one = 1ULL;
    const std::uint64_t mask = (0ULL - (n[0] & one)) >> 12;

    const std::uint64_t t0 = n[0] + (0xFFFFEFFFFFC2FULL & mask);
    const std::uint64_t t1 = n[1] + mask;
    const std::uint64_t t2 = n[2] + mask;
    const std::uint64_t t3 = n[3] + mask;
    const std::uint64_t t4 = n[4] + (mask >> 4);

    // MUST use + (not |): see half() comment above.
    n[0] = (t0 >> 1) + ((t1 & one) << 51);
    n[1] = (t1 >> 1) + ((t2 & one) << 51);
    n[2] = (t2 >> 1) + ((t3 & one) << 51);
    n[3] = (t3 >> 1) + ((t4 & one) << 51);
    n[4] = (t4 >> 1);
}

// -- Multiply by small integer (no carry propagation) ---------------------
// Each limb is multiplied by a (scalar <= 32).
// Safe as long as magnitude * a * 2^52 < 2^64, i.e. magnitude * a < 4096.

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::mul_int_assign(std::uint32_t a) noexcept {
    n[0] *= a;
    n[1] *= a;
    n[2] *= a;
    n[3] *= a;
    n[4] *= a;
}

// -- Full Normalization: canonical result in [0, p) ----------------------
// Fold-first approach (matches libsecp256k1): fold t4 overflow BEFORE carry
// propagation so only 2 carry chains are needed instead of 3.

SECP256K1_FE52_FORCE_INLINE
static void fe52_normalize_inline(std::uint64_t* r) noexcept {
    std::uint64_t t0 = r[0], t1 = r[1], t2 = r[2], t3 = r[3], t4 = r[4];

    // Reduce t4 overflow first (before carry propagation).
    // This ensures at most a single carry from the first pass.
    std::uint64_t m = 0;
    std::uint64_t x = t4 >> 48; t4 &= M48;

    // Single carry propagation pass with m accumulation for >= p check
    t0 += x * 0x1000003D1ULL;
    t1 += (t0 >> 52); t0 &= M52;
    t2 += (t1 >> 52); t1 &= M52; m = t1;
    t3 += (t2 >> 52); t2 &= M52; m &= t2;
    t4 += (t3 >> 52); t3 &= M52; m &= t3;

    // At most a single bit of overflow at bit 48 of t4 (bit 256 of value).
    // Check if result >= p:
    //   bit 48 of t4 set (value >= 2^256), OR
    //   all limbs at max (t1&t2&t3 == M52, t4 == M48, t0 >= p's low 52 bits)
    x = (t4 >> 48) | ((t4 == M48) & (m == M52)
        & (t0 >= 0xFFFFEFFFFFC2FULL));

    // Conditional final reduction (always executed for constant-time)
    t0 += x * 0x1000003D1ULL;
    t1 += (t0 >> 52); t0 &= M52;
    t2 += (t1 >> 52); t1 &= M52;
    t3 += (t2 >> 52); t2 &= M52;
    t4 += (t3 >> 52); t3 &= M52;
    t4 &= M48;

    r[0] = t0; r[1] = t1; r[2] = t2; r[3] = t3; r[4] = t4;
}

// -- Inline Normalization Method -----------------------------------------

SECP256K1_FE52_FORCE_INLINE
void FieldElement52::normalize() noexcept {
    fe52_normalize_inline(n);
}

// -- Variable-time Zero Check (full normalize) ----------------------------
// Uses fe52_normalize_inline (fold-first carry + conditional p-subtraction)
// then checks canonical zero.  The previous single-pass implementation
// could produce false negatives at magnitude >= 25 (e.g. h = u2 +
// negate(23) in mixed-add) because one pass can leave the value in
// [p, 2p) -- neither raw-0 nor raw-p.
//
// Variable-time: safe for non-secret values (point coordinates in ECC).

SECP256K1_FE52_FORCE_INLINE
bool FieldElement52::normalizes_to_zero() const noexcept {
    std::uint64_t t[5] = {n[0], n[1], n[2], n[3], n[4]};
    fe52_normalize_inline(t);
    return (t[0] | t[1] | t[2] | t[3] | t[4]) == 0;
}

// -- Variable-time Zero Check with Early Exit ------------------------------
// Performs a single normalize_weak pass (carry + overflow reduction + carry),
// then checks for raw-zero and p.  Avoids the expensive conditional
// p-subtraction + branchless-select of fe52_normalize_inline.
//
// After one normalize_weak pass at any magnitude <= ~4000, the value is
// in [0, 2p).  The only representations of 0 mod p in [0, 2p) are
// raw-zero (all limbs 0) and p itself.
//
// In the ecmult hot loop, h == 0 occurs with probability ~2^-256,
// so the fast non-zero path fires in essentially 100% of calls.
// This replaces the old normalize_weak() + normalizes_to_zero() pair
// in jac52_add_mixed*, saving ~40 limb ops per mixed add.

SECP256K1_FE52_FORCE_INLINE
bool FieldElement52::normalizes_to_zero_var() const noexcept {
    using namespace fe52_constants;
    std::uint64_t t0 = n[0], t4 = n[4];

    // Reduce t4 overflow into t0 first (at most one carry fold).
    // This ensures the first full carry pass has at most one carry
    // propagation step from the injected overflow.
    const std::uint64_t x = t4 >> 48;
    t0 += x * 0x1000003D1ULL;

    // z0 tracks "could be raw zero", z1 tracks "could be p".
    // If the low 52 bits of t0 are clearly non-zero AND don't match P0,
    // the full value is neither 0 nor p -- early exit without touching n[1..3].
    std::uint64_t z0 = t0 & M52;
    std::uint64_t z1 = z0 ^ 0x1000003D0ULL;

    // Fast return: catches ~100% of cases using only t0 and t4.
    if ((z0 != 0ULL) & (z1 != M52)) {
        return false;
    }

    // Slow path: full carry propagation for the remaining cases.
    std::uint64_t t1 = n[1], t2 = n[2], t3 = n[3];
    t4 &= M48;

    t1 += (t0 >> 52);
    t2 += (t1 >> 52); t1 &= M52; z0 |= t1; z1 &= t1;
    t3 += (t2 >> 52); t2 &= M52; z0 |= t2; z1 &= t2;
    t4 += (t3 >> 52); t3 &= M52; z0 |= t3; z1 &= t3;
                                  z0 |= t4; z1 &= t4 ^ 0xF000000000000ULL;

    return (z0 == 0) | (z1 == M52);
}

// -- Conversion: 4x64 -> 5x52 (inline) -----------------------------------

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::from_fe(const FieldElement& fe) noexcept {
    const auto& L = fe.limbs();
    FieldElement52 r;
    r.n[0] =  L[0]                           & M52;
    r.n[1] = (L[0] >> 52) | ((L[1] & 0xFFFFFFFFFFULL) << 12);
    r.n[2] = (L[1] >> 40) | ((L[2] & 0xFFFFFFFULL)    << 24);
    r.n[3] = (L[2] >> 28) | ((L[3] & 0xFFFFULL)       << 36);
    r.n[4] =  L[3] >> 16;
    return r;
}

// -- Conversion: 5x52 -> 4x64 (inline, includes full normalize) ----------

SECP256K1_FE52_FORCE_INLINE
FieldElement FieldElement52::to_fe() const noexcept {
    FieldElement52 tmp = *this;
    fe52_normalize_inline(tmp.n);

    FieldElement::limbs_type L;
    L[0] =  tmp.n[0]        | (tmp.n[1] << 52);
    L[1] = (tmp.n[1] >> 12) | (tmp.n[2] << 40);
    L[2] = (tmp.n[2] >> 24) | (tmp.n[3] << 28);
    L[3] = (tmp.n[3] >> 36) | (tmp.n[4] << 16);
    return FieldElement::from_limbs_raw(L);  // already canonical -- skip redundant normalize
}

// Convenience serialization: FE52 -> bytes in one call
SECP256K1_FE52_FORCE_INLINE
void FieldElement52::to_bytes_into(std::uint8_t* out) const noexcept {
    // Direct 5x52 -> 32 big-endian bytes (skip intermediate 4x64 conversion).
    // Same approach as libsecp256k1's secp256k1_fe_impl_get_b32.
    FieldElement52 tmp = *this;
    fe52_normalize_inline(tmp.n);

    out[ 0] = static_cast<std::uint8_t>(tmp.n[4] >> 40);
    out[ 1] = static_cast<std::uint8_t>(tmp.n[4] >> 32);
    out[ 2] = static_cast<std::uint8_t>(tmp.n[4] >> 24);
    out[ 3] = static_cast<std::uint8_t>(tmp.n[4] >> 16);
    out[ 4] = static_cast<std::uint8_t>(tmp.n[4] >>  8);
    out[ 5] = static_cast<std::uint8_t>(tmp.n[4]      );
    out[ 6] = static_cast<std::uint8_t>(tmp.n[3] >> 44);
    out[ 7] = static_cast<std::uint8_t>(tmp.n[3] >> 36);
    out[ 8] = static_cast<std::uint8_t>(tmp.n[3] >> 28);
    out[ 9] = static_cast<std::uint8_t>(tmp.n[3] >> 20);
    out[10] = static_cast<std::uint8_t>(tmp.n[3] >> 12);
    out[11] = static_cast<std::uint8_t>(tmp.n[3] >>  4);
    out[12] = static_cast<std::uint8_t>(((tmp.n[2] >> 48) & 0xF) | ((tmp.n[3] & 0xF) << 4));
    out[13] = static_cast<std::uint8_t>(tmp.n[2] >> 40);
    out[14] = static_cast<std::uint8_t>(tmp.n[2] >> 32);
    out[15] = static_cast<std::uint8_t>(tmp.n[2] >> 24);
    out[16] = static_cast<std::uint8_t>(tmp.n[2] >> 16);
    out[17] = static_cast<std::uint8_t>(tmp.n[2] >>  8);
    out[18] = static_cast<std::uint8_t>(tmp.n[2]      );
    out[19] = static_cast<std::uint8_t>(tmp.n[1] >> 44);
    out[20] = static_cast<std::uint8_t>(tmp.n[1] >> 36);
    out[21] = static_cast<std::uint8_t>(tmp.n[1] >> 28);
    out[22] = static_cast<std::uint8_t>(tmp.n[1] >> 20);
    out[23] = static_cast<std::uint8_t>(tmp.n[1] >> 12);
    out[24] = static_cast<std::uint8_t>(tmp.n[1] >>  4);
    out[25] = static_cast<std::uint8_t>(((tmp.n[0] >> 48) & 0xF) | ((tmp.n[1] & 0xF) << 4));
    out[26] = static_cast<std::uint8_t>(tmp.n[0] >> 40);
    out[27] = static_cast<std::uint8_t>(tmp.n[0] >> 32);
    out[28] = static_cast<std::uint8_t>(tmp.n[0] >> 24);
    out[29] = static_cast<std::uint8_t>(tmp.n[0] >> 16);
    out[30] = static_cast<std::uint8_t>(tmp.n[0] >>  8);
    out[31] = static_cast<std::uint8_t>(tmp.n[0]      );
}

// Fast serialize for pre-normalized limbs: 5x52 -> 32 big-endian bytes.
// Skips fe52_normalize_inline (saves ~10 ns per call on pre-normalized inputs).
// Uses bit-slicing to 4x64 intermediary + byte-swap stores.
SECP256K1_FE52_FORCE_INLINE
void FieldElement52::store_b32_prenorm(std::uint8_t* out) const noexcept {
    // 5x52 -> 4x64 bit-slicing (same logic as to_fe, no normalize)
    std::uint64_t L0 =  n[0]        | (n[1] << 52);
    std::uint64_t L1 = (n[1] >> 12) | (n[2] << 40);
    std::uint64_t L2 = (n[2] >> 24) | (n[3] << 28);
    std::uint64_t L3 = (n[3] >> 36) | (n[4] << 16);

    // Big-endian store: 4 bswap + 4 unaligned writes (L3 = MSB)
#if defined(__GNUC__) || defined(__clang__)
    L3 = __builtin_bswap64(L3); L2 = __builtin_bswap64(L2);
    L1 = __builtin_bswap64(L1); L0 = __builtin_bswap64(L0);
#elif defined(_MSC_VER)
    L3 = _byteswap_uint64(L3); L2 = _byteswap_uint64(L2);
    L1 = _byteswap_uint64(L1); L0 = _byteswap_uint64(L0);
#else
    // Portable bswap fallback
    auto bswap64 = [](std::uint64_t v) -> std::uint64_t {
        v = ((v >> 8) & 0x00FF00FF00FF00FFULL) | ((v & 0x00FF00FF00FF00FFULL) << 8);
        v = ((v >> 16) & 0x0000FFFF0000FFFFULL) | ((v & 0x0000FFFF0000FFFFULL) << 16);
        return (v >> 32) | (v << 32);
    };
    L3 = bswap64(L3); L2 = bswap64(L2);
    L1 = bswap64(L1); L0 = bswap64(L0);
#endif
    std::memcpy(out,      &L3, 8);
    std::memcpy(out + 8,  &L2, 8);
    std::memcpy(out + 16, &L1, 8);
    std::memcpy(out + 24, &L0, 8);
}

// -- Direct 4x64 limbs -> 5x52 (no FieldElement construction) -------------
// Same bit-slicing as from_fe but takes raw uint64_t[4] pointer.
// Avoids FieldElement copy + normalization when caller knows value < p.

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::from_4x64_limbs(const std::uint64_t* L) noexcept {
    FieldElement52 r;
    r.n[0] =  L[0]                           & M52;
    r.n[1] = (L[0] >> 52) | ((L[1] & 0xFFFFFFFFFFULL) << 12);
    r.n[2] = (L[1] >> 40) | ((L[2] & 0xFFFFFFFULL)    << 24);
    r.n[3] = (L[2] >> 28) | ((L[3] & 0xFFFFULL)       << 36);
    r.n[4] =  L[3] >> 16;
    return r;
}

// -- Direct bytes (big-endian) -> 5x52 conversion ------------------------
// Combines FieldElement::from_bytes + from_fe into a single step.

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::from_bytes(const std::uint8_t* bytes) noexcept {
    // Read 4 uint64_t limbs from big-endian bytes (same layout as FieldElement::from_bytes)
    std::uint64_t L[4];
    for (int i = 0; i < 4; ++i) {
        std::uint64_t limb = 0;
        for (int j = 0; j < 8; ++j) {
            limb = (limb << 8) | static_cast<std::uint64_t>(bytes[i * 8 + j]);
        }
        L[3 - i] = limb;
    }
    // Reduce mod p if value >= p.
    // p = {0xFFFFFFFEFFFFFC2F, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF}
    static constexpr std::uint64_t P[4] = {
        0xFFFFFFFEFFFFFC2FULL, 0xFFFFFFFFFFFFFFFFULL,
        0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL
    };
    // ge(L, P): check L >= P lexicographically from high limb.
    // NOTE: Variable-time comparison -- acceptable because input bytes
    // are public data (from wire / serialized keys), not secret.
    bool ge_p = true;
    for (int i = 3; i >= 0; --i) {
        if (L[i] < P[i]) { ge_p = false; break; }
        if (L[i] > P[i]) { break; }
    }
    if (ge_p) {
        // L -= P (with borrow), via u128_compat so this builds on armv7 / wasm32
        // where native __int128 is unavailable.
        using u128 = ::secp256k1::detail::u128_compat;
        u128 acc = u128(L[0]) + (~P[0]) + std::uint64_t(1);
        L[0] = static_cast<std::uint64_t>(acc);
        acc = u128(L[1]) + (~P[1]) + static_cast<std::uint64_t>(acc >> 64);
        L[1] = static_cast<std::uint64_t>(acc);
        acc = u128(L[2]) + (~P[2]) + static_cast<std::uint64_t>(acc >> 64);
        L[2] = static_cast<std::uint64_t>(acc);
        L[3] = L[3] + (~P[3]) + static_cast<std::uint64_t>(acc >> 64);
    }
    return from_4x64_limbs(L);
}

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::from_bytes(const std::array<std::uint8_t, 32>& bytes) noexcept {
    return from_bytes(bytes.data());
}

// -- Inverse via safegcd (4x64 round-trip, single wrapper) ---------------
// Replaces the common pattern: FieldElement52::from_fe(x.to_fe().inverse())
// Returns zero for zero input (consistent with noexcept contract + embedded).

SECP256K1_FE52_FORCE_INLINE
FieldElement52 FieldElement52::inverse_safegcd() const noexcept {
    if (SECP256K1_UNLIKELY(normalizes_to_zero_var())) {
        return FieldElement52::zero();
    }
    // Direct 5x52 → signed62 → SafeGCD → signed62 → 5x52.
    // Bypasses the old FE52→to_fe()→inverse()→from_fe() chain
    // which had 4 intermediate format conversions (5x52↔4x64↔signed62).
    FieldElement52 tmp = *this;
    fe52_normalize_inline(tmp.n);
    FieldElement52 r;
    fe52_inverse_safegcd_var(tmp.n, r.n);
    return r;
}

// -- Jacobi/Legendre symbol via posdivstep SafeGCD ----------------------------
// Returns +1 (QR), -1 (NQR), or 0 (zero input).
// Calls fe52_jacobi_var (field.cpp) — same 12-round structure as inverse_safegcd.

// Forward declaration (defined in field.cpp alongside fe52_inverse_safegcd_var)
// fe52_jacobi_var is defined in src/field.cpp under a __SIZEOF_INT128__ guard
// (SafeGCD posdivstep operates on __int128). MSVC has no __int128 and would
// link-fail on the symbol; hide the inline wrapper in lockstep to avoid
// emitting a use-site reference. Callers on MSVC must use the 4x64
// FieldElement::jacobi_var() which has its own non-int128 path. Wasm and
// other 32-bit-with-__int128 targets DO emit the function (Emscripten
// supplies emulated __int128 via compiler-rt).
#if defined(__SIZEOF_INT128__)
extern int fe52_jacobi_var(const std::uint64_t* in5);

SECP256K1_FE52_FORCE_INLINE
int FieldElement52::jacobi_var() const noexcept {
    FieldElement52 tmp = *this;
    fe52_normalize_inline(tmp.n);
    return fe52_jacobi_var(tmp.n);
}
#endif

} // namespace secp256k1::fast

#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif
#endif // __int128 guard

#undef SECP256K1_FE52_FORCE_INLINE

#endif // SECP256K1_FIELD_52_IMPL_HPP
