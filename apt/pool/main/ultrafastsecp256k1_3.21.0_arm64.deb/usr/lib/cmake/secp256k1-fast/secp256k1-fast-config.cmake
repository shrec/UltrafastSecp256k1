
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was secp256k1-fast-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Find threading support
find_dependency(Threads)

# Include targets
include("${CMAKE_CURRENT_LIST_DIR}/secp256k1-fast-targets.cmake")

# Check for required components
set(_SECP256K1_FAST_supported_components CPU CUDA OpenCL)

foreach(_comp ${secp256k1-fast_FIND_COMPONENTS})
    if(NOT _comp IN_LIST _SECP256K1_FAST_supported_components)
        set(secp256k1-fast_FOUND False)
        set(secp256k1-fast_NOT_FOUND_MESSAGE "Unsupported component: ${_comp}")
    endif()
endforeach()

check_required_components(secp256k1-fast)

